import tkinter as tk
from tkinter import messagebox
import math

# Constants
X = 'X'  # Human player
O = 'O'  # AI player
EMPTY = ' '

class TicTacToeGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Tic-Tac-Toe")
        
        # Initialize game state
        self.current_player = X
        self.board = [[EMPTY] * 3 for _ in range(3)]
        
        # Create buttons
        self.buttons = [[None]*3 for _ in range(3)]
        for i in range(3):
            for j in range(3):
                self.buttons[i][j] = tk.Button(self.root, text='', font=('Arial', 60), width=4, height=2,
                                               command=lambda row=i, col=j: self.click(row, col))
                self.buttons[i][j].grid(row=i, column=j)
        
        # AI first move if AI starts
        if self.current_player == O:
            self.ai_move()

    def click(self, row, col):
        # Human player move
        if self.board[row][col] == EMPTY:
            self.board[row][col] = self.current_player
            self.buttons[row][col].config(text=self.current_player)
            
            if self.check_winner(self.current_player):
                self.highlight_winner(self.current_player)
                self.game_over(self.current_player)
            elif self.check_draw():
                self.game_over(None)
            else:
                # Switch turns
                self.current_player = O if self.current_player == X else X
                # AI move
                if self.current_player == O:
                    self.ai_move()

    def ai_move(self):
        # AI player move using Minimax
        _, move = self.minimax(self.board, 0, -math.inf, math.inf, True)
        row, col = move
        self.board[row][col] = O
        self.buttons[row][col].config(text=O)
        
        if self.check_winner(O):
            self.highlight_winner(O)
            self.game_over(O)
        elif self.check_draw():
            self.game_over(None)
        else:
            # Switch turns
            self.current_player = X

    def minimax(self, board, depth, alpha, beta, maximizing_player):
        if self.check_winner(O):
            return 1, None
        elif self.check_winner(X):
            return -1, None
        
        moves = self.get_available_moves(board)
        
        if not moves:
            return 0, None
        
        if maximizing_player:
            max_score = -math.inf
            best_move = None
            for move in moves:
                board[move[0]][move[1]] = O
                score, _ = self.minimax(board, depth + 1, alpha, beta, False)
                board[move[0]][move[1]] = EMPTY
                if score > max_score:
                    max_score = score
                    best_move = move
                alpha = max(alpha, score)
                if beta <= alpha:
                    break
            return max_score, best_move
        else:
            min_score = math.inf
            best_move = None
            for move in moves:
                board[move[0]][move[1]] = X
                score, _ = self.minimax(board, depth + 1, alpha, beta, True)
                board[move[0]][move[1]] = EMPTY
                if score < min_score:
                    min_score = score
                    best_move = move
                beta = min(beta, score)
                if beta <= alpha:
                    break
            return min_score, best_move

    def get_available_moves(self, board):
        moves = []
        for row in range(3):
            for col in range(3):
                if board[row][col] == EMPTY:
                    moves.append((row, col))
        return moves

    def check_winner(self, player):
        # Check rows
        for row in range(3):
            if all(self.board[row][col] == player for col in range(3)):
                self.winning_combination = [(row, col) for col in range(3)]
                return True
        
        # Check columns
        for col in range(3):
            if all(self.board[row][col] == player for row in range(3)):
                self.winning_combination = [(row, col) for row in range(3)]
                return True
        
        # Check diagonals
        if all(self.board[i][i] == player for i in range(3)):
            self.winning_combination = [(i, i) for i in range(3)]
            return True
        if all(self.board[i][2-i] == player for i in range(3)):
            self.winning_combination = [(i, 2-i) for i in range(3)]
            return True
        
        return False

    def highlight_winner(self, player):
        for row, col in self.winning_combination:
            self.buttons[row][col].config(bg='green')

    def check_draw(self):
        for row in self.board:
            if any(cell == EMPTY for cell in row):
                return False
        return True

    def game_over(self, winner):
        if winner:
            messagebox.showinfo("Game Over", f"{winner} wins!")
        else:
            messagebox.showinfo("Game Over", "It's a draw!")
        self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    game = TicTacToeGUI(root)
    root.mainloop()
